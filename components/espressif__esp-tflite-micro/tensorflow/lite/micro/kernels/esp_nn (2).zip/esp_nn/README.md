# Info

These are the Espressif chipset specific replacement kernels.
The kernels call optimized routines or reference routines depending upon optimization option selected.

By default optimizations are selected if available.
To change this behaviour, please make the appropriate `ESP-NN` menu selection after running:

```
idf.py menuconfig
```
